#!/usr/bin/env bash

protoc -I=/usr/include/ -I=./ --go_out=plugins=grpc:. *.proto
